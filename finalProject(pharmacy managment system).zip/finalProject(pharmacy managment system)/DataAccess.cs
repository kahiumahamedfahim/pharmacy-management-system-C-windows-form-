﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalProject_pharmacy_managment_system_
{
   

        public class DataAccess
        {
            private SqlConnection sqlcon;
            public SqlConnection Sqlcon
            {
                get { return this.sqlcon; }
                set { this.sqlcon = value; }
            }

            private SqlCommand sqlcom;
            public SqlCommand Sqlcom
            {
                get { return this.sqlcom; }
                set { this.sqlcom = value; }
            }

            private SqlDataAdapter sda;
            public SqlDataAdapter Sda
            {
                get { return this.sda; }
                set { this.sda = value; }
            }

            private DataSet ds;
            public DataSet Ds
            {
                get { return this.ds; }
                set { this.ds = value; }
            }

            //internal DataTable dt;

            public DataAccess()
            {
            // this.Sqlcon = new SqlConnection(@"Data Source=LAPTOP-HASIB;Initial Catalog=QSpringDb;User ID=sa;Password=P@$$w0rd");
            this.sqlcon= new SqlConnection(@"Data Source=DESKTOP-JVF07FR\SQLEXPRESS;Initial Catalog=""pharmacy managment system"";Persist Security Info=True;User ID=sa;Password=31122001;");
            Sqlcon.Open();
            }

            private void QueryText(string query)
            {
                this.Sqlcom = new SqlCommand(query, this.Sqlcon);
            }

            public DataSet ExecuteQuery(string sql)
            {
                this.Sqlcom = new SqlCommand(sql, this.Sqlcon);//this.QueryText(sql);
                this.Sda = new SqlDataAdapter(this.Sqlcom);
                this.Ds = new DataSet();
                this.Sda.Fill(this.Ds);
                return Ds;
            }

            public DataTable ExecuteQueryTable(string sql)
            {
                this.Sqlcom = new SqlCommand(sql, this.Sqlcon);//this.QueryText(sql);
                this.Sda = new SqlDataAdapter(this.Sqlcom);
                this.Ds = new DataSet();
                this.Sda.Fill(this.Ds);
                return Ds.Tables[0];
            }

            public int ExecuteDMLQuery(string sql)
            {
                this.Sqlcom = new SqlCommand(sql, this.Sqlcon);//this.QueryText(sql);
                int u = this.Sqlcom.ExecuteNonQuery();
                return u;
            }
            public int ExecuteDMLQuery(string sql, params SqlParameter[] parameters)
            {
                this.Sqlcom = new SqlCommand(sql, this.Sqlcon);
                this.Sqlcom.Parameters.AddRange(parameters);
                int u = this.Sqlcom.ExecuteNonQuery();
                return u;
            }
        public DataTable ExecuteQueryTable(string sql, params SqlParameter[] parameters)
        {
            this.Sqlcom = new SqlCommand(sql, this.Sqlcon);
            this.Sqlcom.Parameters.AddRange(parameters);
            this.Sda = new SqlDataAdapter(this.Sqlcom);
            this.Ds = new DataSet();
            this.Sda.Fill(this.Ds);
            return Ds.Tables[0];
        }
    }
    }

